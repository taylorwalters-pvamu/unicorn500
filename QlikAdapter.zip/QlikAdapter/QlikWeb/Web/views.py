from django.shortcuts import render
from Web.forms import UserForm

def adapter(request):
    form = UserForm()
    context = {}
    context['title']='Login'
    context['form']= form
    if request.method == 'POST':
        form = UserForm(request, data=request.POST)
        if form.is_valid():
            return render(request, 'qlik.com')
    else:
        form = UserForm()
    
    return render(request, 'adapter.html', context)

def about(request):
    context = {}
    context['title']= 'About'
    return render(request, 'about.html')

def index(request):
    context = {}
    context['title']= 'Index'
    return render(request, 'index.html')

def demo(request):
    context = {}
    context['title']= 'How it works'
    return render(request, 'demo.html')

def support(request):
    context = {}
    context['title']= 'Support Ticket'
    return render(request, 'support.html')